1、install RT2870USBWirelessDriver.kext to /System/Library/Extensions 
2、install RaWLAPI.framework to /Library/Frameworks 
3、install WirelessUtility to /Applications,set it run on boot.
4、install DWA-140WirelessUtility.prefPane