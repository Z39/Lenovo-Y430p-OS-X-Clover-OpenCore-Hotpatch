Installed BCM94352(Wireless Adapter), Please do the following things: 
1.copy the aml to clover/ACPI/patched
2.Recommend install kext for L/E(/Library/Extensions/), Next run Kext Utility.app Restore permissions and rebuild cache.